# dat250-jpa-examples

1. Import this project as a maven-project such that the database dependencies are loaded.
2. Make sure to change the path in the `persistence.xml` (see TODO).
3. Run Main.java. There should be no exceptions when using Java 11 (Step 4.3)
4. Continue with the tutorial.